//
//  MyGesture.h
//  02-掌握-RunLoop实践
//
//  Created by john on 2019/9/2.
//  Copyright © 2019 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyGesture : UITapGestureRecognizer

@end

NS_ASSUME_NONNULL_END
