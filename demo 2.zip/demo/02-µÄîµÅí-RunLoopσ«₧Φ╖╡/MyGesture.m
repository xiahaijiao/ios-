//
//  MyGesture.m
//  02-掌握-RunLoop实践
//
//  Created by john on 2019/9/2.
//  Copyright © 2019 小码哥. All rights reserved.
//

#import "MyGesture.h"
//#import "UIGestureRecognizerSubclass.h"
#import <UIKit/UIGestureRecognizerSubclass.h>


@implementation MyGesture
-(BOOL)canPreventGestureRecognizer:(UIGestureRecognizer *)preventedGestureRecognizer{
    //YES to indicate that the receiver can block preventedGestureRecognizer from recognizing its gesture, otherwise NO.
    
    return NO;
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"%s",__func__);
    NSLog(@"state:%ld",self.state);
    [super touchesBegan:touches withEvent:event];
}
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"%s",__func__);

    [super touchesMoved:touches withEvent:event];
}
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"%s",__func__);
    [super touchesEnded:touches withEvent:event ];

}
@end
