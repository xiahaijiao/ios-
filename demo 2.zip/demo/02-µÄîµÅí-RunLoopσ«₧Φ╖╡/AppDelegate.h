//
//  AppDelegate.h
//  02-掌握-RunLoop实践
//
//  Created by xiaomage on 15/7/12.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

