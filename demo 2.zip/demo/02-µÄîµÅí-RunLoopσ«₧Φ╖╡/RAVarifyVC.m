//
//  RAVarifyVC.m
//  02-掌握-RunLoop实践
//
//  Created by john on 2019/9/4.
//  Copyright © 2019 小码哥. All rights reserved.
//

#import "RAVarifyVC.h"

@interface RAVarifyVC ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITextField *loginTF;
@property (weak, nonatomic) IBOutlet UITextView *signTV;
@property (weak, nonatomic) IBOutlet UITableView *mytable;

@end

@implementation RAVarifyVC
- (IBAction)doneClick:(id)sender {
    if (self.loginTF.text) {
//        self.getPIN = ^NSString *{
//            return self.loginTF.text;
//        };
        self.getPIN(self.loginTF.text);
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
- (IBAction)alertClick:(id)sender {
    [self showAlert];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    [self.mytable registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
//    NSLog(@"%s",__func__);
//    [self.loginTF resignFirstResponder];
//    BOOL result = [self.signTV becomeFirstResponder];
//    NSLog(@"result = %d",result);
}

-(void)showAlert{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"密吗错误" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert show];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 100;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.textLabel.text =[NSString stringWithFormat:@"hahhah ----  %ld",indexPath.row];
//    cell.detailTextLabel.text = [NSString stringWithFormat:@"hahhah ----  %ld",indexPath.row];
//    cell.backgroundColor = [UIColor blueColor];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"%s",__func__);
}
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    NSLog(@"%s",__func__);

}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    NSLog(@"%s",__func__);

}
@end
