//
//  ViewController.m
//  02-掌握-RunLoop实践
//
//  Created by xiaomage on 15/7/12.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"
#import "XMGThread.h"
#import "MyGesture.h"

#import "RAVarifyVC.h";
NSPort *myport;
NSRunLoop *myrunloop;
BOOL isLoopRunning;



@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
/** 线程对象 */
@property (weak, nonatomic) IBOutlet UITextView *mytxt;



@property(assign)BOOL isrun;




@property (nonatomic, strong) XMGThread *thread;
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.thread = [[XMGThread alloc] initWithTarget:self selector:@selector(execute) object:nil];
//    [self.thread start];
//    [self execute];
    
//    self.view.tou
    UIView *red = [self.view viewWithTag:100];
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapRed)];
    UITapGestureRecognizer *tap = [[MyGesture alloc] initWithTarget:self action:@selector(tapRed)];

    [red addGestureRecognizer:tap];
//    CFRunLoopGetMain();
//    CFRunLoopRun();
//    [self createObserver];
    
    
    UIButton *blue = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
    blue.backgroundColor = [UIColor blueColor];
    [self.mytxt addSubview:blue];
    [blue addTarget:self action:@selector(tapGest:) forControlEvents:UIControlEventTouchUpInside];
    
    
}
-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
//    [self execute];
}
-(void)creatRunloop{
    
    
    
}
-(void)createObserver{
    //创建监听者
    /*
     第一个参数 CFAllocatorRef allocator：分配存储空间 CFAllocatorGetDefault()默认分配
     第二个参数 CFOptionFlags activities：要监听的状态 kCFRunLoopAllActivities 监听所有状态
     第三个参数 Boolean repeats：YES:持续监听 NO:不持续
     第四个参数 CFIndex order：优先级，一般填0即可
     第五个参数 ：回调 两个参数observer:监听者 activity:监听的事件
     */
    /*
     所有事件
     typedef CF_OPTIONS(CFOptionFlags, CFRunLoopActivity) {
     kCFRunLoopEntry = (1UL << 0),   //   即将进入RunLoop
     kCFRunLoopBeforeTimers = (1UL << 1), // 即将处理Timer
     kCFRunLoopBeforeSources = (1UL << 2), // 即将处理Source
     kCFRunLoopBeforeWaiting = (1UL << 5), //即将进入休眠
     kCFRunLoopAfterWaiting = (1UL << 6),// 刚从休眠中唤醒
     kCFRunLoopExit = (1UL << 7),// 即将退出RunLoop
     kCFRunLoopAllActivities = 0x0FFFFFFFU
     };
     */
    
    CFRunLoopObserverRef observer = CFRunLoopObserverCreateWithHandler(CFAllocatorGetDefault(), kCFRunLoopAllActivities, YES, 0, ^(CFRunLoopObserverRef observer, CFRunLoopActivity activity) {
        NSLog(@"activity:%d",activity);
        switch (activity) {
            case kCFRunLoopEntry:
                NSLog(@"RunLoop进入");
                break;
            case kCFRunLoopBeforeTimers:
                NSLog(@"RunLoop要处理Timers了");
                break;
            case kCFRunLoopBeforeSources:
                NSLog(@"RunLoop要处理Sources了");
                break;
            case kCFRunLoopBeforeWaiting:
                NSLog(@"RunLoop要休息了");
                break;
            case kCFRunLoopAfterWaiting:
                NSLog(@"RunLoop醒来了");
                break;
            case kCFRunLoopExit:
                NSLog(@"RunLoop退出了");
                break;
                
            default:
                break;
        }
    });
    
    // 给RunLoop添加监听者
    /*
     第一个参数 CFRunLoopRef rl：要监听哪个RunLoop,这里监听的是主线程的RunLoop
     第二个参数 CFRunLoopObserverRef observer 监听者
     第三个参数 CFStringRef mode 要监听RunLoop在哪种运行模式下的状态
     */
    CFRunLoopAddObserver(CFRunLoopGetCurrent(), observer, kCFRunLoopDefaultMode);
    /*
     CF的内存管理（Core Foundation）
     凡是带有Create、Copy、Retain等字眼的函数，创建出来的对象，都需要在最后做一次release
     GCD本来在iOS6.0之前也是需要我们释放的，6.0之后GCD已经纳入到了ARC中，所以我们不需要管了
     */
    CFRelease(observer);
}
//- (void)execute
//{
//    while (1) {
//        [[NSRunLoop currentRunLoop] run];
//    }
//}

//- (void)execute
//{
//    NSLog(@"1111");
//    [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(test) userInfo:nil repeats:NO];
//
//    [[NSRunLoop currentRunLoop] run];
//    NSLog(@"2222");
//
//
//}

//- (void)execute
//{
//    NSLog(@"----------run----%@", [NSThread currentThread]);
//
//    while (1) {
//        [[NSRunLoop currentRunLoop] run];
//
//        NSLog(@"--------2222");
//    }
//
//    NSLog(@"---------");
//}

//- (void)execute
//{
//    NSLog(@"----------run----%@", [NSThread currentThread]);
//    myport = [NSPort port];
//    myrunloop = [NSRunLoop currentRunLoop];
//    NSLog(@"%@",myport);
//    [[NSRunLoop currentRunLoop] addPort:myport forMode:NSDefaultRunLoopMode];
////    [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(test2) userInfo:nil repeats:NO];
//
//    [[NSRunLoop currentRunLoop] run];
//
//
//    NSLog(@"---------");
//}
- (void)execute
{
    NSLog(@"1111");
    myrunloop = [NSRunLoop currentRunLoop];
//    [myrunloop run];
    while (1) {
        NSLog(@"run");
//            [myrunloop run];
        [[NSRunLoop currentRunLoop] run];
        
//            [myrunloop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];


    }
//    [myrunloop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:2]];
    NSLog(@"2222");
}
- (void)test
{
    NSLog(@"----------test----%@", [NSThread currentThread]);
}

- (void)test2
{
    NSLog(@"***********test2*******%@", [NSThread currentThread]);
//
//    NSLog(@"%@", [NSRunLoop currentRunLoop]);
    NSLog(@"%@",myport);
    [[NSRunLoop currentRunLoop] removePort:myport forMode:NSDefaultRunLoopMode];
//    myport = nil;
//    CFRunLoopStop(CFRunLoopGetCurrent());
    NSLog(@"%p,%p",[NSRunLoop currentRunLoop].getCFRunLoop,myrunloop.getCFRunLoop);
    CFRunLoopStop(myrunloop.getCFRunLoop);
//    [self.thread cancel];
//    self.thread = nil;
//    NSLog(@"%@",myrunloop);
    
}
-(void)showAlert{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"密吗错误" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
    [alert show];
}
- (IBAction)btnClick:(id)sender {
   
    NSLog(@"1111");
//     [self showAlert];
//    [self methodSync];
    
    [self startRunloopScroll];
//    [self skeletonThreadMain];
 

    NSLog(@"2222");
}
-(void)tapRed{
    NSLog(@"tapRed");
//    [self createObserver];
    NSLog(@"tapRed 结束");
}
- (IBAction)tapGest:(id)sender {
    NSLog(@"tapGest");
    
//    [self methodSync];
    
    
    
//    [self createObserver];
//    NSLog(@"%@",[NSThread callStackSymbols]);
//    [self showAlert];

    [self startRunloopScroll];
    
//    [self startRunloop];
//    [self skeletonThreadMain];
    
//    [self createSource];
 
    NSLog(@"tapGest 结束");
 
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"touch begin");
//    UITouch* touch = [touches anyObject];
//    UIView *red = touch.view;
//    [red becomeFirstResponder];
 
}
-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    NSLog(@"touch end");
    [[self nextResponder] touchesEnded:touches withEvent:event];

}
- (IBAction)toolStart:(id)sender {
   
    
}
- (IBAction)toolend:(id)sender {
    NSLog(@"%s",__func__);
    [self stopRunloopScroll];
//    [self stopRunloop];
//    [self stopThread];

    
    
    
}

-(void)startRunloop{
    NSRunLoop *myLoop  = [NSRunLoop currentRunLoop];
    myport = (NSMachPort *)[NSMachPort port];
    [myLoop addPort:myport forMode:NSDefaultRunLoopMode];
    
    isLoopRunning = YES; // global
    
//    while (isLoopRunning && [myLoop runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]]);
    
//    while (isLoopRunning) {
//        NSLog(@"running");
//        [myLoop runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
//    }
//    while (isLoopRunning) {
//        NSLog(@"running");
//
//        [myLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:2]];
//
//    }
    
//    [myLoop run];
    [myLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:10]];
//    BOOL result = [myLoop runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
//    BOOL result = [myLoop runMode:NSDefaultRunLoopMode beforeDate:[NSDate dateWithTimeIntervalSinceNow:2]];

//    NSLog(@"%d",result);
    
}
-(void)stopRunloop{
    isLoopRunning = NO;
    CFRunLoopStop(CFRunLoopGetCurrent());
}

-(void)stopRunloopScroll{
    self.isrun = NO;
//    CFRunLoopStop(CFRunLoopGetCurrent());
    CFRunLoopStop(CFRunLoopGetMain());
    
    
}
-(void)startRunloopScroll{
    
    //防止scroll 释放runloop
      self.isrun = YES;
    while (self.isrun)
        
    {
        /**
        CF_EXPORT void CFRunLoopRun(void);
        CF_EXPORT CFRunLoopRunResult CFRunLoopRunInMode(CFRunLoopMode mode, CFTimeInterval seconds, Boolean returnAfterSourceHandled);
        CF_EXPORT Boolean CFRunLoopIsWaiting(CFRunLoopRef rl);
        CF_EXPORT void CFRunLoopWakeUp(CFRunLoopRef rl);
        CF_EXPORT void CFRunLoopStop(CFRunLoopRef rl);
        */
        
        NSLog(@"running");
//        CFRunLoopRun();
        CFRunLoopRunInMode(kCFRunLoopDefaultMode,1, YES);

        
        /*
         - (void)run;
         - (void)runUntilDate:(NSDate *)limitDate;
         - (BOOL)runMode:(NSRunLoopMode)mode beforeDate:(NSDate *)limitDate;

         */
//        [[NSRunLoop currentRunLoop ] run];
//        NSPort *port = [NSPort port];
//        [[NSRunLoop currentRunLoop] addPort:port forMode:NSDefaultRunLoopMode];

//        [[NSRunLoop currentRunLoop] runMode:NSDefaultRunLoopMode beforeDate:[NSDate distantFuture]];
        
//        [[NSRunLoop mainRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:1]];

        
        
        //        CFRunLoopStop(CFRunLoopGetMain());
        

     }
    
}
   CFRunLoopSourceRef runloopSource_g ;

-(void)createSource{
    CFRunLoopSourceContext  src_context ;
    
        NSError * emsg = nil ;
    
     
    
        // init send source context
    
        src_context.version = 0;
    
        src_context.info = (__bridge void *)(self);
    
        src_context.retain = NULL;
    
        src_context.release = NULL;
    
        src_context.copyDescription = NULL;
    
        src_context.equal = NULL;
    
        src_context.hash = NULL;
    
        src_context.schedule = NULL;
    
        src_context.cancel = NULL;
    
        src_context.perform = &callback ;//设置唤醒是调用的回调函数
    
     
    
        // create send source from context
    
     
    
       CFRunLoopSourceRef runloopSource ;
    
        runloopSource = CFRunLoopSourceCreate (NULL, 0, &src_context) ;
    runloopSource_g = runloopSource;
    
//    2）将source加入线程所属的runloop中
    
     
    
        // add the send source into  run loop
    
        CFRunLoopRef       threadRunLoop ;
    
        threadRunLoop =  CFRunLoopGetCurrent() ;
    
        CFRunLoopAddSource (threadRunLoop ,
                            
                                                    runloopSource,
                            
                                                    kCFRunLoopDefaultMode);
    
//    3)运行runloop
    
       CFRunLoopRun() ;
  
}
- (void)stopThread {
    CFRunLoopStop(CFRunLoopGetCurrent());
    NSThread *thread = [NSThread currentThread];
    [thread cancel];
}
- (void)run {
    @autoreleasepool {
        NSLog(@"current thread = %@", [NSThread currentThread]);
        NSRunLoop *runLoop = [NSRunLoop currentRunLoop];
//        if (!self.emptyPort) {
//            self.emptyPort = [NSMachPort port];
//        }
        NSPort *port =[NSMachPort port];
        [runLoop addPort:port forMode:NSDefaultRunLoopMode];
        [runLoop runMode:NSRunLoopCommonModes beforeDate:[NSDate distantFuture]];
    }
}
- (void)skeletonThreadMain
{
    // Set up an autorelease pool here if not using garbage collection.
    BOOL done = NO;
    
    // Add your sources or timers to the run loop and do any other setup.
    
    do
    {
        // Start the run loop but return after each source is handled.
        SInt32    result = CFRunLoopRunInMode(kCFRunLoopDefaultMode, 1, YES);
//        SInt32    result = CFRunLoopRunInMode(kCFRunLoopDefaultMode, 1, NO);

//        typedef CF_ENUM(SInt32, CFRunLoopRunResult) {
//            kCFRunLoopRunFinished = 1,
//            kCFRunLoopRunStopped = 2,
//            kCFRunLoopRunTimedOut = 3,
//            kCFRunLoopRunHandledSource = 4
//        };
        NSLog(@"running :%d ",result);
        // If a source explicitly stopped the run loop, or if there are no
        // sources or timers, go ahead and exit.
        if ((result == kCFRunLoopRunStopped) || (result == kCFRunLoopRunFinished))
            done = YES;
        
        // Check for any other exit conditions here and set the
        // done variable as needed.
    }
    while (!done);
    
    // Clean up code here. Be sure to release any allocated autorelease pools.
}


/// 用DefaultMode启动
//void CFRunLoopRun(void) {
//    CFRunLoopRunSpecific(CFRunLoopGetCurrent(), kCFRunLoopDefaultMode, 1.0e10, false);
//}
//
///// 用指定的Mode启动，允许设置RunLoop超时时间
//int CFRunLoopRunInMode(CFStringRef modeName, CFTimeInterval seconds, Boolean stopAfterHandle) {
//    return CFRunLoopRunSpecific(CFRunLoopGetCurrent(), modeName, seconds, returnAfterSourceHandled);
//}
void returnAfterSourceHandled(){
    
}
void callback(){
    
}
/// RunLoop的实现
//int CFRunLoopRunSpecific(runloop, modeName, seconds, stopAfterHandle) {
//
//    /// 首先根据modeName找到对应mode
//    CFRunLoopModeRef currentMode = __CFRunLoopFindMode(runloop, modeName, false);
//    /// 如果mode里没有source/timer/observer, 直接返回。
//    if (__CFRunLoopModeIsEmpty(currentMode)) return;
//
//    /// 1. 通知 Observers: RunLoop 即将进入 loop。
//    __CFRunLoopDoObservers(runloop, currentMode, kCFRunLoopEntry);
//
//    /// 内部函数，进入loop
//    __CFRunLoopRun(runloop, currentMode, seconds, returnAfterSourceHandled) {
//
//        Boolean sourceHandledThisLoop = NO;
//        int retVal = 0;
//        do {
//
//            /// 2. 通知 Observers: RunLoop 即将触发 Timer 回调。
//            __CFRunLoopDoObservers(runloop, currentMode, kCFRunLoopBeforeTimers);
//            /// 3. 通知 Observers: RunLoop 即将触发 Source0 (非port) 回调。
//            __CFRunLoopDoObservers(runloop, currentMode, kCFRunLoopBeforeSources);
//            /// 执行被加入的block
//            __CFRunLoopDoBlocks(runloop, currentMode);
//
//            /// 4. RunLoop 触发 Source0 (非port) 回调。
//            sourceHandledThisLoop = __CFRunLoopDoSources0(runloop, currentMode, stopAfterHandle);
//            /// 执行被加入的block
//            __CFRunLoopDoBlocks(runloop, currentMode);
//
//            /// 5. 如果有 Source1 (基于port) 处于 ready 状态，直接处理这个 Source1 然后跳转去处理消息。
//            if (__Source0DidDispatchPortLastTime) {
//                Boolean hasMsg = __CFRunLoopServiceMachPort(dispatchPort, &msg)
//                if (hasMsg) goto handle_msg;
//            }
//
//            /// 通知 Observers: RunLoop 的线程即将进入休眠(sleep)。
//            if (!sourceHandledThisLoop) {
//                __CFRunLoopDoObservers(runloop, currentMode, kCFRunLoopBeforeWaiting);
//            }
//
//            /// 7. 调用 mach_msg 等待接受 mach_port 的消息。线程将进入休眠, 直到被下面某一个事件唤醒。
//            /// • 一个基于 port 的Source 的事件。
//            /// • 一个 Timer 到时间了
//            /// • RunLoop 自身的超时时间到了
//            /// • 被其他什么调用者手动唤醒
//            __CFRunLoopServiceMachPort(waitSet, &msg, sizeof(msg_buffer), &livePort) {
//                mach_msg(msg, MACH_RCV_MSG, port); // thread wait for receive msg
//            }
//
//            /// 8. 通知 Observers: RunLoop 的线程刚刚被唤醒了。
//            __CFRunLoopDoObservers(runloop, currentMode, kCFRunLoopAfterWaiting);
//
//            /// 收到消息，处理消息。
//        handle_msg:
//
//            /// 9.1 如果一个 Timer 到时间了，触发这个Timer的回调。
//            if (msg_is_timer) {
//                __CFRunLoopDoTimers(runloop, currentMode, mach_absolute_time())
//            }
//
//            /// 9.2 如果有dispatch到main_queue的block，执行block。
//            else if (msg_is_dispatch) {
//                __CFRUNLOOP_IS_SERVICING_THE_MAIN_DISPATCH_QUEUE__(msg);
//            }
//
//            /// 9.3 如果一个 Source1 (基于port) 发出事件了，处理这个事件
//            else {
//                CFRunLoopSourceRef source1 = __CFRunLoopModeFindSourceForMachPort(runloop, currentMode, livePort);
//                sourceHandledThisLoop = __CFRunLoopDoSource1(runloop, currentMode, source1, msg);
//                if (sourceHandledThisLoop) {
//                    mach_msg(reply, MACH_SEND_MSG, reply);
//                }
//            }
//
//            /// 执行加入到Loop的block
//            __CFRunLoopDoBlocks(runloop, currentMode);
//
//
//            if (sourceHandledThisLoop && stopAfterHandle) {
//                /// 进入loop时参数说处理完事件就返回。
//                retVal = kCFRunLoopRunHandledSource;
//            } else if (timeout) {
//                /// 超出传入参数标记的超时时间了
//                retVal = kCFRunLoopRunTimedOut;
//            } else if (__CFRunLoopIsStopped(runloop)) {
//                /// 被外部调用者强制停止了
//                retVal = kCFRunLoopRunStopped;
//            } else if (__CFRunLoopModeIsEmpty(runloop, currentMode)) {
//                /// source/timer/observer一个都没有了
//                retVal = kCFRunLoopRunFinished;
//            }
//
//            /// 如果没超时，mode里没空，loop也没被停止，那继续loop。
//        } while (retVal == 0);
//    }
//
//    /// 10. 通知 Observers: RunLoop 即将退出。
//    __CFRunLoopDoObservers(rl, currentMode, kCFRunLoopExit);
//}

#pragma - mark 使用信号量异步转同步

-(NSInteger)methodSync{
//    NSLog(@"开始");
  __block NSInteger result = 0;
//    dispatch_group_t group = dispatch_group_create();
//
//    dispatch_group_enter(group);
    
//    dispatch_sync(dispatch_get_main_queue(), ^{
//        NSLog(@"hahahh");
//    });
    
    
    UIStoryboard *sb= [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    RAVarifyVC *vc =  [sb instantiateViewControllerWithIdentifier:@"RAVarifyVC"];
    
            [self presentViewController:vc  animated:YES completion:nil];
    
    vc.getPIN = ^(NSString * _Nonnull pin) {
        
        NSLog(@"异步结束:%@",pin);
//        CFRunLoopStop(CFRunLoopGetMain());
    };
    
    
    
    
//    [self methodAsync:^(NSInteger result1) {
//
//        result = result1;
//        dispatch_group_leave(group);
//    }];
    
//    dispatch_group_wait(group, DISPATCH_TIME_FOREVER);
//    CFRunLoopRun();
//
//
//    NSLog(@"结束:%d",result);
    
    return result;
}

-(void)methodAsync:( void(^)(NSInteger result))callback{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSLog(@"异步开始");
//        sleep(2);
//        NSLog(@"异步结束");
//        UIStoryboard *sb = [[NSBundle mainBundle] pathForResource:@"Main.storyboard" ofType:nil];
        UIStoryboard *sb= [UIStoryboard storyboardWithName:@"Main" bundle:nil];
       RAVarifyVC *vc =  [sb instantiateViewControllerWithIdentifier:@"RAVarifyVC"];
//        RAVarifyVC *vc = [RAVarifyVC new];
//        vc.getPIN = ^NSString *{
//            
//        };
        
        dispatch_sync(dispatch_get_main_queue(), ^{
            [self presentViewController:vc  animated:YES completion:nil];

        });
        
//        [self presentViewController:vc  animated:YES completion:nil];
        
        vc.getPIN = ^(NSString * _Nonnull pin) {
            
            NSLog(@"异步结束:%@",pin);
            if (callback) {
                    callback(5);
                }
        };
        
        
//        if (callback) {
//            callback(5);
//        }
    });
}

@end
