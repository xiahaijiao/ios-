#import "UIScrollView+UITouch.h"
#define NOTIFICATION_TRANSACTION_FAILED "RA_Transaction_Failed"
extern  BOOL  isRunloopAlertCancel;
 extern  CFRunLoopSourceRef runloopSource_g ;

@implementation UIScrollView (UITouch)

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    
    return;
    /*
     typedef NS_ENUM(NSInteger, UIGestureRecognizerState) {
     
     
     UIGestureRecognizerStatePossible,   // the recognizer has not yet recognized its gesture, but may be evaluating touch events. this is the default state
     
     UIGestureRecognizerStateBegan,   1   // the recognizer has received touches recognized as the gesture. the action method will be called at the next turn of the run loop
     UIGestureRecognizerStateChanged,  2  // the recognizer has received touches recognized as a change to the gesture. the action method will be called at the next turn of the run loop
     UIGestureRecognizerStateEnded,    3  // the recognizer has received touches recognized as the end of the gesture. the action method will be called at the next turn of the run loop and the recognizer will be reset to UIGestureRecognizerStatePossible
     UIGestureRecognizerStateCancelled, 4 // the recognizer has received touches resulting in the cancellation of the gesture. the action method will be called at the next turn of the run loop. the recognizer will be reset to UIGestureRecognizerStatePossible
     
     UIGestureRecognizerStateFailed,     // the recognizer has received a touch sequence that can not be recognized as the gesture. the action method will not be called and the recognizer will be reset to UIGestureRecognizerStatePossible
     
     // Discrete Gestures – gesture recognizers that recognize a discrete event but do not report changes (for example, a tap) do not transition through the Began and Changed states and can not fail or be cancelled
     UIGestureRecognizerStateRecognized = UIGestureRecognizerStateEnded // the recognizer has received touches recognized as the gesture. the action method will be called at the next turn of the run loop and the recognizer will be reset to UIGestureRecognizerStatePossible
     };
     */
    
//    return;
    UITouch* touch = [touches anyObject];
    NSLog(@"gestureRecognizers:%@",touch.gestureRecognizers[0]);
    
    
//       CFRunLoopSourceSignal(runloopSource_g) ;// 参数是你调用的runloop的source
    
       CFRunLoopWakeUp(CFRunLoopGetMain()) ;//这句话的作用时立即执行该runloop的事件，如果没有这句话系统会在空闲的时候执行刚才的runloopSource相关的事件
    CFRunLoopStop(CFRunLoopGetMain()) ;//这个函数可以停掉runloop是线程正常退出
    

    
    UIView* view = [touch view];
    NSArray *gArr = [touch gestureRecognizers];
    UILongPressGestureRecognizer *tap;
//    NSLog(@"runloop: %@",[NSRunLoop mainRunLoop]);

    
//    UIWindow *win = [touch window];
//    NSLog(@"%@,%@,%@",view,gArr,win);
    return;
    /*
     <_UIAlertControllerActionView: 0x10861c550; frame = (0 0; 270 44); Action = <UIAlertAction: 0x2810d4fc0 Title = "确定" Descriptive = "(null)" Image = 0x0>>
     
     */
    if( [view isKindOfClass:NSClassFromString(@"_UIAlertControllerActionView")]){
        
        NSArray *stack = [NSThread callStackSymbols];
//        NSLog(@"%@",stack);
        
        //    BOOL isContain= [stack containsObject:@"startRunloopScroll"];
        BOOL isContain= [self iscontainRunloop:stack];
        
        if(isContain){
            if (isRunloopAlertCancel) {
                isRunloopAlertCancel = NO;

                return;
            }
            [[NSNotificationCenter defaultCenter] postNotificationName:@NOTIFICATION_TRANSACTION_FAILED object:self];
            
            NSLog(@"isContain ");
        }
    }
    
   
}
-(BOOL)iscontainRunloop:(NSArray*)arrray{
    
    BOOL iscontain= NO;
    for (NSString *symbol in arrray) {
       iscontain =  [symbol containsString:@"startRunloopScroll"];
        if (iscontain) {
            NSLog(@"有 startRunloopScroll ");
//            CFRunLoopStop([[NSRunLoop mainRunLoop] getCFRunLoop]);
            break;
        }
    }
    return iscontain;
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesMoved:touches withEvent:event];
//    NSRunLoop *runllop = [NSRunLoop currentRunLoop];
//    CFRunLoopStop(runllop.getCFRunLoop);
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
}

@end
